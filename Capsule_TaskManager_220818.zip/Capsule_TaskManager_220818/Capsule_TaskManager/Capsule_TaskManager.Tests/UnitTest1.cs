﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Capsule_TaskManager.Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
